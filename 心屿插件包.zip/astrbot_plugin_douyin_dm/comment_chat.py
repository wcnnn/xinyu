"""她在评论区跟别人聊天。

不是只回复 @ 她的人，而是刷完一条视频后，
挑评论区里值得接话的，接一句。

护栏：
  · 每小时最多聊 5 次
  · 不回攻击性内容
  · 不回广告、拉人
  · 不回超大人气账号（免得被围观）
  · 同一个人的评论只回一次
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

# 一眼就别回的类型
BAD_PATTERNS = [
    r'加[我薇vV微]|[Vv]\s*[:：]?\s*\w{5,}|威信|微信',
    r'代[购发刷]|兼职|日赚|月入|躺赚|引流|私信我',
    r'死|滚|傻[逼比]|脑残|垃圾|废物|狗东西',
    r'举报|投诉|封号',
]

# 一看就是不想深入聊的短句
LOW_VALUE = {
    '哈哈哈', '哈哈', '啊', '哦', '嗯', '好', '赞', '牛', '顶',
    '1', '2', '3', '。', '...', '。。。', '？', '?',
}


def _is_bad(text: str) -> bool:
    t = text or ''
    for p in BAD_PATTERNS:
        if re.search(p, t):
            return True
    return False


def _too_short(text: str) -> bool:
    t = (text or '').strip()
    if len(t) < 4:
        return True
    if t in LOW_VALUE:
        return True
    return False


def _looks_like_to_her(text: str, names: list[str]) -> bool:
    """明确在跟她说话。"""
    t = (text or '').strip()
    for n in names:
        if n and (f'@{n}' in t or (n in t[:15] and len(t) < 40)):
            return True
    if re.search(r'[?？]\s*$', t) and len(t) <= 40:
        return True
    for kw in ('回我', '理我', '在吗', '你在'):
        if kw in t:
            return True
    return False


class CommentChatter:
    """在评论区跟人聊天。"""

    def __init__(self, owner, *, hourly_cap=5, per_video=1,
                 log_path: Path | None = None):
        self.owner = owner
        self.hourly_cap = hourly_cap
        self.per_video = per_video
        self.log_path = log_path or (
            Path(str(owner.data_dir)) / "comment_chat.log")
        self._state_file = (
            Path(str(owner.data_dir)) / "comment_chat_state.json")
        st = self._load()
        self._replied: list[str] = st.get("replied", [])
        self._timestamps: list[float] = st.get("times", [])

    # ------------------------------------------------------------ 记录

    def _log(self, msg: str):
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%m-%d %H:%M:%S')}  {msg}\n")
        except Exception:
            pass

    def _load(self) -> dict:
        try:
            return json.loads(self._state_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save(self):
        try:
            self._state_file.write_text(json.dumps({
                "replied": self._replied[-400:],
                "times": self._timestamps[-100:],
            }, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------ 配额

    def _used_last_hour(self) -> int:
        now = time.time()
        self._timestamps = [t for t in self._timestamps if now - t < 3600]
        return len(self._timestamps)

    def can_chat(self) -> bool:
        return self._used_last_hour() < self.hourly_cap

    # ------------------------------------------------------------ 挑人

    def _self_names(self) -> list[str]:
        out = []
        for key in ("nickname", "bot_name", "self_name"):
            v = self.owner.config.get(key)
            if v:
                out.append(str(v).strip())
        out.append("糯糯")
        return [n for n in dict.fromkeys(out) if n]

    @staticmethod
    def _key(url: str, user: str) -> str:
        return f"{url}|{user}"

    def _pick(self, url: str, comments: list, names: list[str]):
        """从这一条视频的评论里挑一个值得聊的。"""
        chosen = 0
        for c in comments:
            if chosen >= self.per_video:
                break
            user = str(c.get("user") or "").strip()
            text = str(c.get("text") or "").strip()

            if not user or not text:
                continue
            # 自己发的跳过
            if any(n and n in user for n in names):
                continue
            # 回过的跳过
            if self._key(url, user) in self._replied:
                continue
            # 垃圾内容跳过
            if _is_bad(text):
                self._log(f"跳过（不良内容）：{user}")
                continue
            if _too_short(text):
                continue

            return user, text
        return None

    # ------------------------------------------------------------ 主流程

    async def maybe_chat(self, url: str) -> bool:
        """刷完一条之后，看看要不要在评论区聊两句。"""
        if not self.can_chat():
            return False
        if not url:
            return False

        names = self._self_names()
        try:
            # 这是刚看过的视频，走 comments() 就行
            raw = await self.owner.activities.comments(url)
        except Exception as exc:
            self._log(f"读评论区失败 {url[-16:]}: "
                      f"{type(exc).__name__}: {str(exc)[:60]}")
            return False

        comments = []
        if isinstance(raw, dict):
            comments = raw.get("comments") or []
        elif isinstance(raw, list):
            comments = raw
        if not comments:
            return False

        pick = self._pick(url, comments, names)
        if not pick:
            return False
        user, text = pick

        reply = await self._think(user, text, names)
        if not reply:
            return False

        try:
            # 刚看过这条，reply_comment 的校验能过
            r = await self.owner.activities.reply_comment(url, user, reply)
            state = r.get("state") if isinstance(r, dict) else "?"
        except Exception as exc:
            self._log(f"发送失败 {type(exc).__name__}: {str(exc)[:80]}")
            return False

        self._log(f"跟「{user}」聊：{text[:20]} → {reply[:30]} [{state}]")
        self._replied.append(self._key(url, user))
        self._timestamps.append(time.time())
        self._save()
        return state in ("sent", "unknown")

    async def _think(self, user: str, text: str, names: list[str]) -> str:
        """让她想一句怎么接。"""
        try:
            provider = await self.owner._get_provider()
            if provider is None:
                return ""
            from astrbot.core.agent.message import Message, TextPart

            to_her = _looks_like_to_her(text, names)
            hint = ("这条明显是在跟你说话，直接回应他"
                    if to_her else "这条是在说视频本身，你就着这个话题接一句")
            prompt = (
                f"你在刷视频，看到评论区有人这样写：\n"
                f"「{user}」：{text[:100]}\n\n"
                f"{hint}。\n"
                f"用你自己的口气回一句（6～30 字，像平时跟网友聊天那样，"
                f"别客套、别用「您好」「感谢分享」这类）。"
                f"如果这条你实在没什么好说的，只回 SKIP。不要解释。"
            )
            resp = await provider.text_chat(
                contexts=[Message(role="user",
                                  content=[TextPart(text=prompt)])],
                max_tokens=80)
            out = (getattr(resp, "completion_text", "") or "").strip()
        except Exception as exc:
            self._log(f"生成失败 {type(exc).__name__}: {str(exc)[:60]}")
            return ""

        if not out or "SKIP" in out.upper():
            return ""
        out = out.strip('"').strip("「」").split("\n")[0][:60]
        if len(out) < 2 or _is_bad(out):
            return ""
        return out