"""Daily watch-time budget persisted in the plugin ledger.

The budget counts watched *content* seconds (video duration, with a small
floor for image posts) rather than wall-clock time, so it stays meaningful
even when the perception model is slow.
"""
from __future__ import annotations

import datetime
import time

from .errors import BrowserError

KEY_PREFIX = 'watch-budget:'
MIN_CHARGE_SECONDS = 15.0


def _today():
    return datetime.datetime.now().strftime('%Y-%m-%d')


def _day_key():
    return KEY_PREFIX + _today()


def limit_seconds(owner):
    """Return the daily cap in seconds, or None when the cap is disabled."""
    if not owner.config.get('daily_limit_enabled', True):
        return None
    raw = owner.config.get('daily_limit_minutes', 90)
    if raw is None or raw == '':
        minutes = 90.0
    else:
        try:
            minutes = float(raw)
        except (TypeError, ValueError):
            minutes = 90.0
    if minutes <= 0:
        return None
    return minutes * 60.0


def used_seconds(owner):
    record = owner.ledger.get(_day_key()) or {}
    try:
        return max(0.0, float(record.get('seconds') or 0))
    except (TypeError, ValueError):
        return 0.0


def remaining_seconds(owner):
    limit = limit_seconds(owner)
    if limit is None:
        return None
    return max(0.0, limit - used_seconds(owner))


def ensure_available(owner):
    """Raise when today's budget is exhausted."""
    left = remaining_seconds(owner)
    if left is not None and left <= 0:
        limit = limit_seconds(owner) or 0.0
        raise BrowserError(
            f'今天已经刷满 {int(round(limit / 60))} 分钟了，明天再来吧。'
        )


def charge(owner, seconds):
    """Add watched seconds to today's tally and return the new total."""
    if limit_seconds(owner) is None:
        return used_seconds(owner)
    amount = max(0.0, float(seconds or 0))
    if amount <= 0:
        return used_seconds(owner)
    key = _day_key()
    record = dict(owner.ledger.get(key) or {})
    total = used_seconds(owner) + amount
    record['seconds'] = total
    record['day'] = _today()
    record['updated_at'] = time.time()
    owner.ledger.put(key, record)
    return total


def describe(owner):
    """Summary used by status surfaces and tests."""
    limit = limit_seconds(owner)
    used = used_seconds(owner)
    if limit is None:
        return {'enabled': False, 'used_seconds': round(used, 1)}
    return {
        'enabled': True,
        'used_seconds': round(used, 1),
        'limit_seconds': round(limit, 1),
        'remaining_seconds': round(max(0.0, limit - used), 1),
        'used_minutes': round(used / 60.0, 1),
        'limit_minutes': round(limit / 60.0, 1),
    }
