"""文字卡片生成：用 PIL 把一段话渲染成适合发抖音的图片。

不依赖任何绘图服务，纯本地渲染。
"""

from __future__ import annotations

import random
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
]

# 几种配色，随机挑一种，避免每张都一样
THEMES = [
    {"bg": (24, 28, 40), "fg": (240, 242, 248), "accent": (120, 180, 255)},
    {"bg": (250, 246, 240), "fg": (48, 44, 40), "accent": (214, 120, 80)},
    {"bg": (30, 48, 42), "fg": (232, 244, 238), "accent": (140, 220, 170)},
    {"bg": (46, 32, 52), "fg": (246, 236, 248), "accent": (220, 150, 230)},
    {"bg": (255, 250, 235), "fg": (60, 54, 44), "accent": (230, 170, 60)},
]

SIZE = (1080, 1440)  # 3:4，抖音竖向图片比例


def _font(size: int):
    for path in FONT_CANDIDATES:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def make_text_card(text: str, out_path: str, signature: str = "") -> str:
    """把文字渲染成一张卡片图，返回文件路径。"""
    body = (text or "").strip()
    if not body:
        raise ValueError("卡片文字为空")

    theme = random.choice(THEMES)
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)

    # 简单的渐变装饰
    for i in range(0, SIZE[1], 4):
        ratio = i / SIZE[1]
        color = tuple(
            int(theme["bg"][c] * (1 - ratio * 0.25) + theme["accent"][c] * ratio * 0.08)
            for c in range(3)
        )
        draw.line([(0, i), (SIZE[0], i)], fill=color)

    # 正文
    font_size = 64 if len(body) <= 40 else 52 if len(body) <= 90 else 42
    font = _font(font_size)
    wrap_chars = max(8, int((SIZE[0] - 200) / font_size))
    lines = []
    for para in body.split("\n"):
        lines.extend(textwrap.wrap(para, width=wrap_chars) or [""])

    line_height = int(font_size * 1.6)
    total_height = len(lines) * line_height
    y = max(180, (SIZE[1] - total_height) // 2)

    for line in lines:
        width = draw.textlength(line, font=font)
        x = (SIZE[0] - width) // 2
        draw.text((x, y), line, font=font, fill=theme["fg"])
        y += line_height

    # 装饰线
    draw.rectangle(
        [(SIZE[0] // 2 - 40, y + 30), (SIZE[0] // 2 + 40, y + 36)],
        fill=theme["accent"],
    )

    # 署名
    if signature:
        sig_font = _font(34)
        w = draw.textlength(signature, font=sig_font)
        draw.text(
            ((SIZE[0] - w) // 2, SIZE[1] - 160),
            signature,
            font=sig_font,
            fill=theme["accent"],
        )

    target = Path(out_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    img.save(target, "JPEG", quality=88)
    return str(target)