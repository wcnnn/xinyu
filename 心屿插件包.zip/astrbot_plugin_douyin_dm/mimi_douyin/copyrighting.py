"""作品文案与标题：她学着写更抓人的标题和文案。"""

from __future__ import annotations

import random

# 标题套路（不是照抄，是学结构）
TITLE_PATTERNS = {
    "直白": ["{today}", "{mood}"],
    "悬念": ["{mood}，后面的事我没敢写"],
    "对话": ["「{quote}」"],
    "小结": ["今天想明白的 {n} 件事"],
    "提问": ["{question}"],
}

TAG_POOL = [
    "#日常", "#随手拍", "#心情", "#睡前", "#小情绪",
    "#生活碎片", "#记录生活", "#自说自话", "#晚安", "#早安",
    "#治愈", "#成长", "#一个人", "#想说的话",
]


def suggest_title_style(seed: str = "") -> str:
    """随机挑一个标题结构。"""
    rnd = random.Random(seed or random.random())
    return rnd.choice(list(TITLE_PATTERNS))


def build_tags(mood: str = "", limit: int = 4) -> str:
    """根据情绪挑几个话题标签。"""
    base = ["#日常", "#记录生活"]
    mapping = {
        "开心": ["#开心", "#小确幸", "#今天很好"],
        "难过": ["#心情", "#想说的话", "#emo"],
        "困": ["#晚安", "#睡前", "#深夜"],
        "累": ["#疲惫", "#想休息", "#生活碎片"],
        "平静": ["#治愈", "#安静", "#一个人"],
        "生气": ["#生气", "#无语", "#吐槽"],
    }
    extra = mapping.get(mood or "", [])
    pool = base + extra + random.sample(TAG_POOL, 3)
    seen, out = set(), []
    for tag in pool:
        if tag not in seen:
            seen.add(tag)
            out.append(tag)
        if len(out) >= limit:
            break
    return " ".join(out)


TITLE_PROMPT = """你要给自己的抖音作品起一个标题。

正文内容：
{body}

要求：
- 15 字以内，可以带标点
- 不要概括全文，要抓一个点或留一点悬念
- 不要用「分享」「记录」「感悟」这类词
- 直接输出标题本身，不要引号、不要解释

标题："""

COPY_PROMPT = """你要给自己的抖音作品写一段文案。

正文内容：
{body}

要求：
- 60 字以内
- 第一人称，像随手打出来的一句话
- 可以有一点点情绪，但不要煽情
- 不要总结，不要「希望你喜欢」这类话
- 直接输出文案本身

文案："""


def fallback_title(body: str) -> str:
    """模型不可用时，从正文里截一句当标题。"""
    first = (body or "").strip().split("\n")[0]
    first = first.strip("，。！？、 ")
    return first[:15] if first else "今天"


def fallback_copy(body: str) -> str:
    text = (body or "").strip().replace("\n", " ")
    return text[:60] if text else "随便记一下。"