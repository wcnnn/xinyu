class BrowserError(RuntimeError):
    pass
