import {openBackgroundPage} from './browser_actions.mjs';

/**
 * 进直播间，看弹幕、发一句打招呼的话。
 * 抖音直播的 URL 形如 https://live.douyin.com/<房间号> 或 https://www.douyin.com/root/live/<房间号>
 */
export async function enterLive(args,environment) {
  const {context,page}=environment;
  const tab=await openBackgroundPage(context,page);
  const url=String(args?.url||'').trim();
  if(!url) throw new Error('没有直播链接');

  await tab.goto(url,{waitUntil:'domcontentloaded',timeout:45000});
  await tab.waitForTimeout(9000);
  await tab.bringToFront().catch(()=>{});

  const info=await tab.evaluate(()=>{
    const body=document.body.innerText||'';
    const hostNode=document.querySelector('[class*="nickname"],[class*="anchor"],[class*="host"]');
    const titleNode=document.querySelector('[class*="title"],[class*="room"]');
    const editables=[...document.querySelectorAll('[contenteditable="true"],textarea,input')]
      .filter(e=>e.offsetParent!==null)
      .map(e=>({tag:e.tagName,ph:e.getAttribute('placeholder')||'',cls:(e.className||'').slice(0,40)}));
    return {
      url:location.href,
      title:document.title,
      hasVideo:!!document.querySelector('video'),
      needLogin:/扫码登录|请登录/.test(body),
      living:/正在直播|直播中/.test(body),
      host:(hostNode?.innerText||'').trim().slice(0,30),
      roomTitle:(titleNode?.innerText||'').trim().slice(0,60),
      editables,
      sample:body.replace(/\n+/g,' | ').slice(0,400),
    };
  });
  return info;
}

/** 在直播间发一句话（弹幕/聊天） */
export async function sayInLive(args,environment) {
  const {context,page}=environment;
  const tab=await openBackgroundPage(context,page);
  const text=String(args?.text||'').trim();
  if(!text) throw new Error('没有要说的话');
  if(text.length>50) throw new Error('直播间发言太长，限 50 字以内');

  // 页面已经由 enterLive 打开过；如果没打开就再进一次
  if(!/live/i.test(tab.url()||'')) {
    if(!args?.url) throw new Error('需要先在直播间里');
    await tab.goto(String(args.url),{waitUntil:'domcontentloaded',timeout:45000});
    await tab.waitForTimeout(9000);
  }
  await tab.bringToFront().catch(()=>{});

  // 找直播间的聊天输入框（真实占位符是「与大家互动一下...」）
  // 必须用 evaluateHandle 拿 Playwright 句柄，不能直接返回 DOM 元素
  const handle = await tab.evaluateHandle(()=>{
    const nodes=[...document.querySelectorAll('[contenteditable="true"],textarea,input,div[class*="input"]')]
      .filter(e=>e.offsetParent!==null);
    const want=/与大家互动|说点什么|发弹幕|聊两句/;
    const byPh=nodes.find(e=>want.test(e.getAttribute('placeholder')||''));
    if(byPh)return byPh;
    const editable=nodes.filter(e=>e.matches('[contenteditable="true"],textarea,input'));
    if(!editable.length)return null;
    editable.sort((a,b)=>{
      const ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
      return (rb.top+rb.left)-(ra.top+ra.left);
    });
    return editable[0];
  });
  const el = handle.asElement();
  if(!el) throw new Error('找不到直播间输入框');

  await el.click();
  await tab.waitForTimeout(500);
  await tab.keyboard.type(text,{delay:60});
  await tab.waitForTimeout(800);

  // 回车或点发送
  const sent=await tab.evaluate(()=>{
    const btns=[...document.querySelectorAll('button,div,span')];
    const b=btns.find(n=>/^(发送|评论)$/.test((n.innerText||'').trim())&&n.children.length===0);
    if(b){b.click();return 'click';}
    return '';
  });
  if(!sent) await tab.keyboard.press('Enter');
  await tab.waitForTimeout(3000);

  const verify=await tab.evaluate(t=>{
    // 只认弹幕区里的这句话，排除输入框里还没提交的残留
    const hits=[...document.querySelectorAll('div,span,p')].filter(n=>{
      if(n.children.length>0)return false;
      if(!(n.innerText||'').includes(t))return false;
      return !n.closest('[contenteditable="true"],textarea,input');
    }).length;
    return {appeared:hits>0};
  },text);

  return {state:verify.appeared?'sent':'unknown', text, how:sent||'enter'};
}