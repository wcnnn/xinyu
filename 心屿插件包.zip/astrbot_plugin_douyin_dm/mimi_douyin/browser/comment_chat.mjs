import {openBackgroundPage} from './browser_actions.mjs';
import {getCommentEditor} from './comment_ui.mjs';

/** 读取评论区列表：作者名 + 正文 */
export async function readComments(args,environment) {
  const {context,page}=environment;
  const tab=await openBackgroundPage(context,page);
  const url=String(args?.url||'');
  await tab.goto(url,{waitUntil:'domcontentloaded',timeout:45000});
  await tab.waitForTimeout(2500);

  // 打开评论区
  for(const sel of ['[data-e2e="comment-icon"]','[data-e2e="feed-comment-icon"]']) {
    try{
      const button=tab.locator(sel).first;
      if(await button.count()&&await button.isVisible()) {await button.click({timeout:2500});break;}
    }catch{}
  }
  await tab.waitForTimeout(1800);

  const items=await tab.evaluate(()=>{
    const nodes=[...document.querySelectorAll('[data-e2e="comment-item"]')];
    return nodes.slice(0,15).map(node=>{
      const userNode=node.querySelector('[class*="nickname"],[class*="name"],a[href*="/user/"]');
      const textNode=node.querySelector('[class*="content"],[class*="text"],span');
      return {
        user:(userNode?.innerText||'').trim().slice(0,30),
        text:(textNode?.innerText||'').trim().slice(0,120),
      };
    }).filter(item=>item.text);
  });
  return {url,comments:items};
}

/** 回复评论区某一条：点它的"回复"，输入文字，回车发送 */
export async function replyComment(args,environment) {
  const {context,page}=environment;
  const tab=await openBackgroundPage(context,page);
  const url=String(args?.url||'');
  const target=String(args?.user||'').trim();
  const text=String(args?.text||'').trim();
  if(!text) throw new Error('回复内容为空');

  await tab.goto(url,{waitUntil:'domcontentloaded',timeout:45000});
  await tab.waitForTimeout(2500);
  for(const sel of ['[data-e2e="comment-icon"]','[data-e2e="feed-comment-icon"]']) {
    try{
      const button=tab.locator(sel).first;
      if(await button.count()&&await button.isVisible()) {await button.click({timeout:2500});break;}
    }catch{}
  }
  await tab.waitForTimeout(1800);

  // 找到目标评论那一行
  let clicked=false;
  if(target) {
    const row=tab.locator('[data-e2e="comment-item"]').filter({hasText:target}).first();
    if(await row.count()) {
      for(const sel of ['[class*="reply"]','text=回复']) {
        try{
          const btn=row.locator(sel).first;
          if(await btn.count()&&await btn.isVisible()) {await btn.click({timeout:2500});clicked=true;break;}
        }catch{}
      }
    }
  }
  if(!clicked) {
    // 找不到就退化为在总输入框留言
    const editor=await getCommentEditor(tab);
    if(!editor) throw new Error('找不到评论输入框');
    await editor.click();
    await editor.pressSequentially?.(text,{delay:60}) ?? await tab.keyboard.type(text,{delay:60});
    await editor.press('Enter');
    await tab.waitForTimeout(2500);
    return {state:'sent_generic',target,text};
  }

  const editor=await getCommentEditor(tab);
  if(!editor) throw new Error('找不到回复输入框');
  await editor.click();
  await tab.keyboard.type(text,{delay:60});
  await tab.waitForTimeout(300);
  await tab.keyboard.press('Enter');
  await tab.waitForTimeout(2500);
  return {state:'sent_reply',target,text};
}