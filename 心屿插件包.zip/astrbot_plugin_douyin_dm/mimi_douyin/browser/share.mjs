// 分享抖音作品给指定的人：在评论区 @ 他，让他收到提醒。
// 比"转发私信"可靠——转发入口经常变，@ 是标准入口。

import { openBackgroundPage } from './browser_actions.mjs';

function pickPostID(url) {
  const m = String(url || '').match(/\/(?:video|note)\/(\d{12,24})/);
  return m ? m[1] : '';
}

export async function shareToFriend(args, environment) {
  const { context, page, siteHost } = environment;
  const url = String(args.url || '');
  const postID = pickPostID(url);
  const friend = String(args.friend || '').trim();
  const note = String(args.note || '').trim();

  if (!url.startsWith('https://')) throw new Error('分享需要有效的抖音作品链接。');
  if (!postID) throw new Error('链接里找不到作品编号。');
  if (!friend) throw new Error('没有指定要分享给谁。');
  if (note.length > 120) throw new Error('想说的话太长了。');

  const tab = await openBackgroundPage(context, page);
  try {
    try { await tab.bringToFront(); } catch (e) {}
    await tab.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });

    const title = await tab.title();
    if (/验证码|安全验证/.test(title)) {
      throw new Error('分享页要求账号验证，请先手动完成。');
    }
    if (!new URL(tab.url()).pathname.includes(postID)) {
      throw new Error('作品页已经变了，没分享出去。');
    }

    // 打开评论区
    await tab.waitForTimeout(2000);
    for (const sel of ['[data-e2e="comment-icon"]', '[data-e2e="feed-comment-icon"]']) {
      try {
        const b = tab.locator(sel).first;
        if ((await b.count()) && (await b.isVisible())) {
          await b.click({ timeout: 2500 });
          break;
        }
      } catch (e) {}
    }
    await tab.waitForTimeout(1500);

    try { await tab.bringToFront(); } catch (e) {}

    // 抖音的评论框是 Draft.js：先点容器，才会出现真正的编辑器
    const container = tab.locator('.comment-input-inner-container').first();
    if (!(await container.count())) throw new Error('没找到评论输入区。');
    await container.click({ timeout: 6000 });
    await tab.waitForTimeout(1500);

    const editor = tab.locator('.public-DraftEditor-content').first();
    if (!(await editor.count())) throw new Error('评论框没激活。');
    await editor.click({ timeout: 5000 });
    await tab.waitForTimeout(300);

    // Draft.js 清空要用键盘
    await tab.keyboard.press('Control+A');
    await tab.keyboard.type(' ', { delay: 30 });
    await tab.keyboard.press('Backspace');
    await tab.waitForTimeout(250);

    // @ 触发提及下拉
    await tab.keyboard.type('@', { delay: 150 });
    await tab.waitForTimeout(2500);

    // 抖音的 @ 列表是横排头像卡片，不是 li。
    // 先试输入昵称筛选，再点第一个头像。
    await tab.keyboard.type(friend, { delay: 130 });
    await tab.waitForTimeout(2500);

    let picked = false;

    // @ 列表是横排的头像卡片，每张下面带昵称。
    // 必须读出昵称做精确比对——绝不能"点第一个"，那会 @ 错人。
    const cards = await tab
      .evaluate(() => {
        const out = [];
        const input = document.querySelector('.comment-input-inner-container');
        if (!input) return out;
        const ir = input.getBoundingClientRect();

        // 在输入框正下方那一块里找候选：每个候选 = 一个头像 + 相邻文字
        const root = input.closest('div[class]')?.parentElement?.parentElement
          || document.body;

        root.querySelectorAll('*').forEach((el) => {
          const r = el.getBoundingClientRect();
          if (r.top < ir.bottom - 12 || r.top > ir.bottom + 260) return;
          if (r.width < 30 || r.width > 160) return;
          if (r.height < 30 || r.height > 140) return;

          // 文本要短，像昵称
          const txt = (el.innerText || '').trim();
          if (!txt || txt.length > 24 || txt.includes('\n')) return;
          // 元素里得有个图（头像）
          if (!el.querySelector('img') && el.tagName !== 'IMG') return;

          out.push({
            name: txt,
            x: Math.round(r.x + r.width / 2),
            y: Math.round(r.y + r.height / 2),
          });
        });

        // 去重
        const seen = new Set();
        return out.filter((p) => {
          const k = Math.round(p.x / 40) + ',' + Math.round(p.y / 40);
          if (seen.has(k)) return false;
          seen.add(k);
          return true;
        }).slice(0, 20);
      })
      .catch(() => []);

    // 精确匹配：昵称必须完全等于目标（或去掉首尾空白后等于）
    const target = friend.trim();
    let hit = null;
    for (const c of cards) {
      const n = String(c.name || '').trim();
      if (n === target) {
        hit = c;
        break;
      }
    }
    // 精确没有，就找"包含"且唯一的（比如昵称后面带了别的字符）
    if (!hit) {
      const partial = cards.filter((c) =>
        String(c.name || '').trim().includes(target));
      if (partial.length === 1) hit = partial[0];
    }

    if (hit) {
      try {
        await tab.mouse.click(hit.x, hit.y);
        picked = true;
        await tab.waitForTimeout(1200);
      } catch (e) {}
    }

    // 找不到就宁可不发，绝不瞎点
    if (!picked) {
      const seen = cards.map((c) => c.name).filter(Boolean).slice(0, 6);
      return {
        state: 'not_found',
        post_id: postID,
        share_to: friend,
        candidates: seen,
        reason: 'no_exact_match',
      };
    }

    if (note) {
      await tab.keyboard.type(' ' + note, { delay: 70 });
      await tab.waitForTimeout(500);
    }

    const waitReceipt = (ms) =>
      tab
        .waitForResponse((r) => /comment\/publish\//.test(r.url()), { timeout: ms })
        .then(async (r) => { try { return await r.json(); } catch (e) { return null; } })
        .catch(() => null);

    let result = null;
    const pending = waitReceipt(12000);
    try {
      await tab.keyboard.press('Enter');
    } catch (e) {}
    result = await pending;

    // 有时候抓不到接口响应，但输入框被清空了就说明发出去了
    await tab.waitForTimeout(1200);
    const cleared = await tab
      .evaluate(() => {
        const box = document.querySelector('.public-DraftEditor-content');
        if (!box) return true;              // 编辑器消失 = 已提交
        const t = (box.innerText || '').trim();
        return t.length === 0;
      })
      .catch(() => false);

    const cid =
      result?.comment?.cid ||
      result?.data?.comment?.cid ||
      result?.comment_id ||
      result?.data?.comment_id ||
      '';

    if (cid) {
      return {
        state: 'sent',
        post_id: postID,
        share_to: friend,
        mention_clicked: picked,
        comment_id: String(cid),
        receipt: 'server_comment_id',
      };
    }
    if (cleared) {
      // 输入框被清空 = 提交成功（抖音不总是返回可读回执）
      return {
        state: 'sent',
        post_id: postID,
        share_to: friend,
        mention_clicked: picked,
        receipt: 'editor_cleared',
      };
    }
    return {
      state: 'unknown',
      post_id: postID,
      share_to: friend,
      mention_clicked: picked,
      reason: result ? 'server_rejected' : 'no_receipt',
    };
  } finally {
    try { await tab.close(); } catch (e) {}
  }
}