import {openBackgroundPage} from './browser_actions.mjs';

/**
 * 发布图文/视频到抖音。
 * 关键：创作页初始只有「上传视频」区域，必须上传后表单才出现，发布按钮也才存在。
 */
export async function publishPost(args,environment) {
  const {context,page}=environment;
  const tab=await openBackgroundPage(context,page);

  const images=Array.isArray(args?.images)?args.images:[];
  const video=String(args?.video||'').trim();
  const title=String(args?.title||'').trim();
  const isVideo=!!video;
  if(!isVideo&&!images.length) throw new Error('没有要发布的内容');
  if(!title) throw new Error('标题为空');

  await tab.goto('https://creator.douyin.com/creator-micro/content/upload',{waitUntil:'domcontentloaded',timeout:45000});
  await tab.waitForTimeout(4000);

  if(!isVideo) {
    // 「发布图文」是叶子文本节点，必须用 evaluate 精确点击才生效
    const switched=await tab.evaluate(()=>{
      const nodes=[...document.querySelectorAll('div,span,a,li')];
      const target=nodes.find(n=>(n.innerText||'').trim()==='发布图文'&&n.children.length===0);
      if(target){target.click();return true;}
      return false;
    });
    if(!switched) throw new Error('切不到「发布图文」标签');
    await tab.waitForTimeout(3000);
  }

  // 页面上有两个 file input：第一个只收视频，第二个才是图片。
  // 用 file input 的 accept 精确匹配，再用 filechooser 兜底。
  const files=isVideo?[video]:images;
  const wantImage=!isVideo;
  const inputs=tab.locator('input[type="file"]');
  const total=await inputs.count();
  let uploaded=false;
  for(let i=0;i<total;i++) {
    const el=inputs.nth(i);
    const accept=String(await el.getAttribute('accept')||'').toLowerCase();
    const match=wantImage?accept.includes('image'):accept.includes('video');
    if(!match) continue;
    await el.setInputFiles(files);
    uploaded=true;
    break;
  }
  if(!uploaded) {
    // 兜底：点「上传图文/上传视频」按钮触发 filechooser
    const label=wantImage?'上传图文':'上传视频';
    const [chooser]=await Promise.all([
      tab.waitForEvent('filechooser',{timeout:10000}).catch(()=>null),
      tab.evaluate(l=>{
        const nodes=[...document.querySelectorAll('button,div,span')];
        const b=nodes.find(n=>(n.innerText||'').trim()===l&&n.children.length===0);
        if(b){b.click();return true;}
        return false;
      },label),
    ]);
    if(!chooser) throw new Error('找不到可用的上传入口（可能需要登录创作平台）');
    await chooser.setFiles(files);
  }

  let formReady=false;
  const rounds=isVideo?90:40;
  for(let i=0;i<rounds;i++) {
    await tab.waitForTimeout(2000);
    formReady=await tab.evaluate(()=>{
      const body=document.body.innerText||'';
      const hasForm=/作品描述|发布设置|谁可以看/.test(body);
      const uploading=/上传中|正在上传|\d+%/.test(body);
      return hasForm&&!uploading;
    });
    if(formReady) break;
  }
  if(!formReady) throw new Error('上传后没等到发布按钮出现，可能被审核卡住或上传失败');
  await tab.waitForTimeout(1500);

  const titleBox=tab.locator('input[placeholder*="标题"], textarea[placeholder*="标题"]').first();
  if(await titleBox.count()) {
    await titleBox.click();
    await tab.keyboard.type(title,{delay:40});
    await tab.waitForTimeout(800);
  }

  let published=false;
  for(const sel of ['button:text-is("发布")','button:text-is("立即发布")','[class*="button"]:text-is("发布")']) {
    try{
      const btn=tab.locator(sel).last();
      if(await btn.count()&&await btn.isVisible()) {
        await btn.click({timeout:4000});
        published=true;
        break;
      }
    }catch{}
  }
  if(!published) throw new Error('找到了表单但没点到发布按钮');

  await tab.waitForTimeout(6000);
  const confirm=await tab.evaluate(()=>{
    const body=document.body.innerText||'';
    const href=location.href;
    // 发布成功后抖音会跳到内容管理页，带 enter_from=publish
    const jumped=/content\/manage|enter_from=publish/.test(href);
    return {
      url:href,
      success:jumped||/发布成功|已发布|审核中/.test(body),
      published_url:jumped?href:'',
      needVerify:/安全验证|滑块|验证码/.test(body),
    };
  });
  return {state:confirm.success?'published':'unknown',...confirm,title,kind:isVideo?'video':'image',count:isVideo?1:images.length};
}

export async function postPageState(args,environment) {
  const {context,page}=environment;
  const tab=await openBackgroundPage(context,page);
  await tab.goto('https://creator.douyin.com/creator-micro/content/upload',{waitUntil:'domcontentloaded',timeout:45000});
  await tab.waitForTimeout(3000);
  return await tab.evaluate(()=>({
    url:location.href,
    hasFileInput:!!document.querySelector('input[type="file"]'),
    text:(document.body.innerText||'').slice(0,600),
  }));
}
