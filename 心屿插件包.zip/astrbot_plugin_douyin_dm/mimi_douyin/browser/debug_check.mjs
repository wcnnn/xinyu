
import { openBackgroundPage } from './browser_actions.mjs';
export async function inspect(args, environment) {
  const { context, page } = environment;
  const tab = await openBackgroundPage(context, page);
  await tab.goto(args.url, { waitUntil: 'domcontentloaded', timeout: 45000 });
  await tab.waitForTimeout(2500);
  for (const sel of ['[data-e2e="feed-comment-icon"]']) {
    try { const b = tab.locator(sel).first; if (await b.count()) await b.click({ timeout: 3000 }); break; } catch(e) {}
  }
  await tab.waitForTimeout(3000);

  // 找自己发的评论（含"这个给你看看""测试一下"之类）
  const marks = args.marks || [];
  const found = await tab.evaluate((marks) => {
    const out = [];
    document.querySelectorAll('*').forEach((el) => {
      if (el.children.length > 3) return;
      const t = (el.innerText || '').trim();
      if (!t || t.length > 60) return;
      for (const m of marks) {
        if (t.includes(m)) {
          out.push({ text: t.slice(0, 50), cls: String(el.className || '').slice(0, 50) });
          break;
        }
      }
    });
    return out.slice(0, 10);
  }, marks).catch(() => []);

  await tab.close();
  return { found };
}
