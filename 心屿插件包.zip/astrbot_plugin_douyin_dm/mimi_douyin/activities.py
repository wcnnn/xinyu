"""Grounded browsing and comment receipts shared by both entry points."""
import asyncio
import hashlib
import json
import time
from urllib.parse import urlsplit
from .budget import MIN_CHARGE_SECONDS, charge, ensure_available
from .errors import BrowserError
from .media import prepare_video
from .perception import transcribe_video

class ActivityEngine:
    def __init__(self,owner,perceive=transcribe_video):
        self.owner=owner;self.perceive=perceive;self.lock=asyncio.Lock()

    async def _ensure_browser(self):
        """确保浏览器已打开（发布需要 page 存在）。"""
        owner = self.owner
        status = await owner.browser.call('status', {}, timeout=15)
        if status.get('open'):
            return
        open_browser = getattr(owner, 'open_browser', None)
        if callable(open_browser):
            await open_browser()
            return
        config = getattr(owner.browser, 'config', None) or {}
        await owner.browser.open(config.get('restore_peer'))

    async def watch(self,url='',prefer_images=False,info_only=False):
        async with self.lock:
            owner=self.owner
            if not info_only:ensure_available(owner)
            seen=[key.split(':',1)[1] for (key,) in owner.ledger.db.execute("SELECT key FROM state WHERE key LIKE 'activity:%'").fetchall()]
            source=await owner.browser.call('browse',{'url':url,'seen_ids':seen[-100:],
                'prefer_images':prefer_images,'info_only':info_only},timeout=150)
            if info_only:return {'source':source}
            if source.get('path'):
                source['path']=await prepare_video(source['path'],owner.media_dir,owner.ffmpeg_binary,
                    float(owner.config.get('max_model_video_mb',18)),expected_duration=source.get('duration'),ffprobe_binary=owner.ffprobe_binary)
            source['url']=source.pop('source','')
            source['origin']='self_browse'
            transcript=await self.perceive(owner,[source])
            record={'verified':True,'post_id':source.get('post_id'),'url':source['url'],'kind':source.get('kind','video'),
                    'transcript':transcript,'watched_at':time.time(),'persona_scope':getattr(owner,'persona',None),
                    'owner_scope':owner.binding['peer']['key'] if getattr(owner,'binding',None) else None}
            if not record['post_id']:raise BrowserError('没有确认作品标识，未登记观看记录。')
            owner.ledger.put('activity:'+record['post_id'],record)
            charge(owner,max(float(source.get('duration') or 0),MIN_CHARGE_SECONDS))
            return {'record':record,'source':source}

    async def comment(self,url,text):
        owner=self.owner
        if not owner.config.get('allow_public_comments',False):raise BrowserError('评论开关未开启。')
        import re
        post_id=re.search(r'/(?:video|note)/(\d{12,24})',urlsplit(url).path)
        parsed=urlsplit(url);record=owner.ledger.get('activity:'+post_id[1]) if post_id else None
        if (parsed.scheme!='https' or not (parsed.hostname=='douyin.com' or str(parsed.hostname).endswith('.douyin.com'))
                or parsed.username or parsed.password or not record or record.get('verified') is not True):
            raise BrowserError('先实际读取这条作品，再根据内容评论。')
        text=str(text).strip()
        if not text or len(text)>200:raise BrowserError('评论正文应为 1～200 字。')
        key='comment:'+post_id[1]+':'+hashlib.sha256(text.encode()).hexdigest()
        previous=owner.ledger.get(key)
        if previous:return {**previous,'already_submitted':True}
        owner.ledger.put(key,{'state':'unknown','post_id':post_id[1],'text':text,'submitted_at':time.time()})
        try:receipt=await owner.browser.call('comment',{'url':url,'text':text},timeout=90)
        except Exception:
            # A timeout can occur after the site accepted a comment. Keep the
            # unknown marker so the same text is never submitted automatically.
            raise
        owner.ledger.put(key,{**receipt,'text':text,'submitted_at':time.time()})
        return receipt

    async def comments(self, url):
        """读评论区，返回 [{user, text}, ...]。"""
        owner = self.owner
        if not owner.config.get('allow_public_comments', False):
            raise BrowserError('评论开关未开启。')
        return await self._guard_activity('read_comments', {'url': url}, url)

    async def reply_comment(self, url, user, text):
        """回复评论区某条评论。"""
        owner = self.owner
        if not owner.config.get('allow_public_comments', False):
            raise BrowserError('评论开关未开启。')
        text = str(text or '').strip()
        if not text or len(text) > 60:
            raise BrowserError('回复内容应为 1～60 字。')
        return await self._guard_activity(
            'reply_comment', {'url': url, 'user': user, 'text': text}, url
        )

    async def comments_own(self, url):
        """读她自己作品下面的评论。

        跟 comments() 的区别：不要求先有观看记录——
        她自己的作品本来就不在观看账本里。
        """
        owner = self.owner
        if not owner.config.get('allow_public_comments', False):
            raise BrowserError('评论开关未开启。')
        from urllib.parse import urlsplit

        parsed = urlsplit(url)
        if (
            parsed.scheme != 'https'
            or not (parsed.hostname == 'douyin.com'
                    or str(parsed.hostname).endswith('.douyin.com'))
        ):
            raise BrowserError('不是抖音地址。')
        return await owner.browser.call(
            'read_comments', {'url': url}, timeout=90)

    async def reply_own(self, url, user, text):
        """回复自己作品下面的评论（同样不要求观看记录）。"""
        owner = self.owner
        if not owner.config.get('allow_public_comments', False):
            raise BrowserError('评论开关未开启。')
        text = str(text or '').strip()
        if not text or len(text) > 60:
            raise BrowserError('回复内容应为 1～60 字。')
        return await owner.browser.call(
            'reply_comment', {'url': url, 'user': user, 'text': text},
            timeout=90)

    async def _guard_activity(self, action, args, url):
        """统一做作品校验 + 调用浏览器。"""
        owner = self.owner
        import re
        from urllib.parse import urlsplit

        post_id = re.search(r'/(?:video|note)/(\d{12,24})', urlsplit(url).path)
        record = owner.ledger.get('activity:' + post_id[1]) if post_id else None
        parsed = urlsplit(url)
        if (
            parsed.scheme != 'https'
            or not (parsed.hostname == 'douyin.com' or str(parsed.hostname).endswith('.douyin.com'))
            or parsed.username
            or parsed.password
            or not record
            or record.get('verified') is not True
        ):
            raise BrowserError('先实际读取这条作品，再去看评论区。')
        return await owner.browser.call(action, args, timeout=90)

    # ------------------------------------------------------------------ 发作品

    async def publish_card(self, text, title="", signature="—— 糯糯"):
        """把一段文字做成卡片图并发到抖音。需要 allow_publish 开启。"""
        owner = self.owner
        if not owner.config.get('allow_publish', False):
            raise BrowserError('自己发作品的开关没开。')
        from .card import make_text_card
        from pathlib import Path
        import time as _time

        media_dir = Path(owner.config.get('media_dir') or '.').expanduser()
        cards_dir = media_dir / 'cards'
        cards_dir.mkdir(parents=True, exist_ok=True)
        card_path = cards_dir / f'card-{int(_time.time())}.jpg'
        make_text_card(text, str(card_path), signature=signature)

        if not str(title).strip():
            title = str(text).strip().replace('\n', ' ')[:30]

        await self._ensure_browser()
        receipt = await owner.browser.call(
            'publish_post',
            {'images': [str(card_path)], 'title': str(title)[:55]},
            timeout=180,
        )
        url = receipt.get('published_url') or receipt.get('url') or ''
        owner.ledger.put('publish:' + str(int(_time.time())), {
            'state': receipt.get('state'),
            'title': title,
            'card': str(card_path),
            'url': url,
            'at': _time.time(),
        })
        return {'card': str(card_path), **receipt}

    async def publish_video(self, text, title="", signature="—— 糯糯"):
        """把一段文字做成竖屏视频并发到抖音。需要 allow_publish 开启。"""
        owner = self.owner
        if not owner.config.get('allow_publish', False):
            raise BrowserError('自己发作品的开关没开。')
        from .cardvideo import make_text_video
        from pathlib import Path
        import time as _time

        media_dir = Path(owner.config.get('media_dir') or '.').expanduser()
        videos_dir = media_dir / 'videos'
        videos_dir.mkdir(parents=True, exist_ok=True)
        video_path = videos_dir / f'video-{int(_time.time())}.mp4'
        make_text_video(text, str(video_path), signature=signature)

        if not str(title).strip():
            title = str(text).strip().replace('\n', ' ')[:30]

        await self._ensure_browser()
        receipt = await owner.browser.call(
            'publish_post',
            {'video': str(video_path), 'title': str(title)[:55]},
            timeout=300,
        )
        # 一定要把作品地址存下来——以后要去评论区看谁 @ 了她
        url = receipt.get('published_url') or receipt.get('url') or ''
        owner.ledger.put('publish:' + str(int(_time.time())), {
            'state': receipt.get('state'),
            'kind': 'video',
            'title': title,
            'file': str(video_path),
            'url': url,
            'at': _time.time(),
        })
        return {'video': str(video_path), **receipt}


    # ------------------------------------------------------------------ 直播间

    async def enter_live(self, url):
        """进直播间，返回房间信息（主播、标题、能否发言）。"""
        owner = self.owner
        await self._ensure_browser()
        info = await owner.browser.call('enter_live', {'url': url}, timeout=120)
        owner.ledger.put('live:' + str(int(__import__('time').time())), info)
        return info

    async def say_live(self, url, text):
        """在直播间说一句话。"""
        owner = self.owner
        await self._ensure_browser()
        return await owner.browser.call(
            'say_live', {'url': url, 'text': str(text)[:50]}, timeout=90
        )

    # ------------------------------------------------------------------ 发作品（升级版）

    async def publish_card_v2(self, text, title="", style="", theme="", signature="—— 糯糯"):
        """发图文：多种样式 + 自动配标题文案 + 自动话题。"""
        owner = self.owner
        if not owner.config.get('allow_publish', False):
            raise BrowserError('自己发作品的开关没开。')
        from .cardstyles import render_card
        from .copyrighting import build_tags
        from pathlib import Path
        import time as _time

        media_dir = Path(owner.config.get('media_dir') or '.').expanduser()
        cards_dir = media_dir / 'cards'
        cards_dir.mkdir(parents=True, exist_ok=True)
        card_path = cards_dir / f'card-{int(_time.time())}.jpg'
        render_card(text, str(card_path), style=style, theme=theme,
                    title=title, signature=signature)

        if not str(title).strip():
            title = await self._make_title(text)
        tags = build_tags()
        final_title = f"{title} {tags}"[:80]

        await self._ensure_browser()
        receipt = await owner.browser.call(
            'publish_post',
            {'images': [str(card_path)], 'title': final_title},
            timeout=180,
        )
        owner.ledger.put('publish:' + str(int(_time.time())), {
            'state': receipt.get('state'), 'kind': 'image',
            'title': final_title, 'card': str(card_path), 'at': _time.time(),
        })
        return {'card': str(card_path), 'title': final_title, **receipt}

    async def publish_video_v2(self, text, title="", signature="—— 糯糯",
                               with_bgm=True, with_voice=True):
        """发视频：文字视频 + 背景音乐 + 她自己配音。"""
        owner = self.owner
        if not owner.config.get('allow_publish', False):
            raise BrowserError('自己发作品的开关没开。')
        from .cardvideo import make_text_video
        from .audio import fetch_any_music, synthesize_voice, mix_into_video, duration_of
        from .copyrighting import build_tags
        from pathlib import Path
        import time as _time

        media_dir = Path(owner.config.get('media_dir') or '.').expanduser()
        videos_dir = media_dir / 'videos'
        videos_dir.mkdir(parents=True, exist_ok=True)
        stamp = int(_time.time())
        raw_path = videos_dir / f'video-{stamp}.mp4'
        make_text_video(text, str(raw_path), signature=signature)

        final_path = raw_path
        bgm = None
        voice = None
        if with_bgm:
            try:
                bgm = fetch_any_music(str(media_dir / 'music'), log=lambda m: None)
            except Exception:
                bgm = None
        if with_voice:
            try:
                voice_path = videos_dir / f'voice-{stamp}.wav'
                synthesize_voice(text.replace("\n", "，"), str(voice_path))
                voice = str(voice_path)
            except Exception:
                voice = None

        if bgm or voice:
            try:
                mixed = videos_dir / f'video-mixed-{stamp}.mp4'
                mix_into_video(str(raw_path), str(mixed), bgm=bgm, voice=voice)
                final_path = mixed
            except Exception:
                final_path = raw_path

        if not str(title).strip():
            title = await self._make_title(text)
        tags = build_tags()
        final_title = f"{title} {tags}"[:80]

        await self._ensure_browser()
        receipt = await owner.browser.call(
            'publish_post',
            {'video': str(final_path), 'title': final_title},
            timeout=300,
        )
        owner.ledger.put('publish:' + str(int(_time.time())), {
            'state': receipt.get('state'), 'kind': 'video',
            'title': final_title, 'file': str(final_path),
            'bgm': bool(bgm), 'voice': bool(voice), 'at': _time.time(),
        })
        return {'video': str(final_path), 'title': final_title,
                'has_bgm': bool(bgm), 'has_voice': bool(voice), **receipt}

    async def _make_title(self, body):
        """让模型给正文起标题；模型不可用就截正文。"""
        from .copyrighting import TITLE_PROMPT, fallback_title
        owned = self.owner
        text_fn = getattr(owned, "_text", None)
        if callable(text_fn):
            try:
                peer = ""
                binding = getattr(owned, "binding", None)
                if binding:
                    peer = binding["peer"]["key"]
                title = await text_fn(TITLE_PROMPT.format(body=str(body)[:300]), peer)
                title = (title or "").strip().strip('"').strip("「」").split("\n")[0][:20]
                if title:
                    return title
            except Exception:
                pass
        return fallback_title(body)

    # ------------------------------------------------------------------ 从看过的视频截表情包

    async def meme_from_watched(self, url, mood="reply", tags="", caption="", at_seconds=0.45):
        """从她刚看过的视频里截一帧，存成表情包。"""
        owner = self.owner
        import re
        from urllib.parse import urlsplit
        from pathlib import Path
        from .frames2meme import grab_frame, save_as_meme

        post_id = re.search(r'/(?:video|note)/(\d{12,24})', urlsplit(url).path)
        if not post_id:
            raise BrowserError('这个链接不是作品链接。')
        record = owner.ledger.get('activity:' + post_id[1])
        if not record or record.get('verified') is not True:
            raise BrowserError('先实际看过这条作品，才能从里面截图。')

        video_path = record.get('path') or record.get('video_path') or ''
        if not video_path or not Path(str(video_path)).exists():
            raise BrowserError('这条作品的视频文件已经不在缓存里了，重新看一遍再截。')

        media_dir = Path(owner.config.get('media_dir') or '.').expanduser()
        frame_path = media_dir / 'frames' / f'frame-{post_id[1]}.jpg'
        grab_frame(str(video_path), str(frame_path), at_seconds=at_seconds)

        packs_root = Path(__file__).resolve().parents[3] / 'plugin_data' / 'meme_manager' / 'packs'
        target = save_as_meme(str(frame_path), packs_root, mood, tags, caption)
        owner.ledger.put('meme:' + post_id[1] + ':' + mood, {
            'path': str(target), 'tags': tags, 'caption': caption,
        })
        return {'meme': str(target), 'mood': mood, 'tags': tags}
