"""图文卡片的多种样式：她可以挑不同的风格发作品。"""

from __future__ import annotations

import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT_BOLD = r"C:\Windows\Fonts\msyhbd.ttc"
FONT_NORMAL = r"C:\Windows\Fonts\msyh.ttc"
FONT_KAI = r"C:\Windows\Fonts\simkai.ttf"
FONT_HEI = r"C:\Windows\Fonts\simhei.ttf"

THEMES = {
    "夜色": {"bg": (18, 22, 34), "fg": (238, 242, 250), "accent": (110, 170, 255)},
    "暖阳": {"bg": (252, 246, 236), "fg": (52, 46, 38), "accent": (222, 128, 72)},
    "森林": {"bg": (26, 44, 38), "fg": (232, 246, 238), "accent": (130, 214, 168)},
    "暮紫": {"bg": (42, 30, 50), "fg": (246, 238, 250), "accent": (206, 148, 232)},
    "奶油": {"bg": (255, 251, 240), "fg": (58, 52, 42), "accent": (232, 176, 72)},
    "雾蓝": {"bg": (226, 234, 242), "fg": (36, 44, 56), "accent": (72, 122, 186)},
    "墨白": {"bg": (250, 250, 250), "fg": (24, 24, 24), "accent": (24, 24, 24)},
}

SIZE = (1080, 1440)


def _font(path: str, size: int):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _wrap(text: str, font, max_width: int) -> list[str]:
    lines: list[str] = []
    for para in (text or "").split("\n"):
        if not para:
            lines.append("")
            continue
        current = ""
        for ch in para:
            trial = current + ch
            if font.getlength(trial) <= max_width:
                current = trial
            else:
                lines.append(current)
                current = ch
        if current:
            lines.append(current)
    return lines


def _gradient(img: Image.Image, top, bottom) -> None:
    w, h = img.size
    draw = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        color = tuple(int(top[i] * (1 - t) + bottom[i] * t) for i in range(3))
        draw.line([(0, y), (w, y)], fill=color)


def _fit_font(text: str, max_lines: int, max_width: int) -> tuple:
    """从大到小试字号，让文字刚好放得下。"""
    for size in (86, 76, 68, 60, 54, 48, 42, 36, 32):
        font = _font(FONT_BOLD, size)
        lines = _wrap(text, font, max_width)
        if len(lines) <= max_lines:
            return font, lines
    font = _font(FONT_BOLD, 30)
    return font, _wrap(text, font, max_width)


# --------------------------------------------------------------------- 样式


def style_classic(text: str, theme: dict, signature: str) -> Image.Image:
    """经典：居中大字。"""
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)
    font, lines = _fit_font(text, 12, SIZE[0] - 220)
    lh = int(font.size * 1.62)
    total = len(lines) * lh
    y = max(200, (SIZE[1] - total) // 2)

    for line in lines:
        w = draw.textlength(line, font=font)
        draw.text(((SIZE[0] - w) / 2, y), line, font=font, fill=theme["fg"])
        y += lh

    draw.rectangle([(SIZE[0] // 2 - 46, y + 34), (SIZE[0] // 2 + 46, y + 40)], fill=theme["accent"])

    if signature:
        sf = _font(FONT_NORMAL, 34)
        sw = draw.textlength(signature, font=sf)
        draw.text(((SIZE[0] - sw) / 2, SIZE[1] - 170), signature, font=sf, fill=theme["accent"])
    return img


def style_quote(text: str, theme: dict, signature: str) -> Image.Image:
    """引用：左侧竖线 + 左对齐。"""
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)
    margin = 130
    font, lines = _fit_font(text, 10, SIZE[0] - margin * 2 - 70)
    lh = int(font.size * 1.65)
    total = len(lines) * lh
    top = max(240, (SIZE[1] - total) // 2)

    draw.rectangle([(margin, top - 20), (margin + 8, top + total)], fill=theme["accent"])

    y = top
    for line in lines:
        draw.text((margin + 52, y), line, font=font, fill=theme["fg"])
        y += lh

    if signature:
        sf = _font(FONT_NORMAL, 36)
        draw.text((margin + 52, y + 40), signature, font=sf, fill=theme["accent"])
    return img


def style_poem(text: str, theme: dict, signature: str) -> Image.Image:
    """诗：竖排，从右往左。"""
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)
    body = (text or "").replace("\n", "，")
    size = 64 if len(body) <= 50 else 54 if len(body) <= 90 else 44
    font = _font(FONT_KAI, size)
    step = int(size * 1.5)
    max_rows = (SIZE[1] - 320) // step

    chars = [c for c in body if c.strip()]
    cols = []
    while chars:
        cols.append(chars[:max_rows])
        chars = chars[max_rows:]

    x = SIZE[0] - 170
    for col in cols:
        y = 180
        for ch in col:
            draw.text((x, y), ch, font=font, fill=theme["fg"])
            y += step
        x -= step

    if signature:
        sf = _font(FONT_KAI, 36)
        draw.text((140, SIZE[1] - 170), signature, font=sf, fill=theme["accent"])
    return img


def style_note(text: str, theme: dict, signature: str) -> Image.Image:
    """便签：卡片感，带阴影。"""
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)

    margin = 120
    card = Image.new("RGB", (SIZE[0] - margin * 2, int(SIZE[1] * 0.62)), (255, 255, 255))
    cdraw = ImageDraw.Draw(card)
    font, lines = _fit_font(text, 9, card.size[0] - 140)
    lh = int(font.size * 1.6)
    total = len(lines) * lh
    y = max(70, (card.size[1] - total) // 2)

    for line in lines:
        w = cdraw.textlength(line, font=font)
        cdraw.text(((card.size[0] - w) / 2, y), line, font=font, fill=(48, 44, 40))
        y += lh

    shadow = Image.new("RGB", card.size, (0, 0, 0))
    shadow = shadow.filter(ImageFilter.GaussianBlur(24))
    cy = (SIZE[1] - card.size[1]) // 2
    img.paste(shadow, (margin + 10, cy + 18))
    img.paste(card, (margin, cy))

    if signature:
        sf = _font(FONT_NORMAL, 34)
        sw = draw.textlength(signature, font=sf)
        draw.text(((SIZE[0] - sw) / 2, cy + card.size[1] + 50), signature, font=sf, fill=theme["accent"])
    return img


def style_title_body(title: str, text: str, theme: dict, signature: str) -> Image.Image:
    """标题 + 正文：上方大字标题，下方小字正文。"""
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)

    tf = _font(FONT_BOLD, 78)
    tlines = _wrap(title, tf, SIZE[0] - 220)[:2]
    y = 260
    for line in tlines:
        w = draw.textlength(line, font=tf)
        draw.text(((SIZE[0] - w) / 2, y), line, font=tf, fill=theme["fg"])
        y += int(tf.size * 1.4)

    y += 40
    draw.rectangle([(SIZE[0] // 2 - 40, y), (SIZE[0] // 2 + 40, y + 6)], fill=theme["accent"])
    y += 70

    bf, blines = _fit_font(text, 9, SIZE[0] - 240)
    lh = int(bf.size * 1.62)
    for line in blines:
        w = draw.textlength(line, font=bf)
        draw.text(((SIZE[0] - w) / 2, y), line, font=bf, fill=theme["fg"])
        y += lh

    if signature:
        sf = _font(FONT_NORMAL, 32)
        sw = draw.textlength(signature, font=sf)
        draw.text(((SIZE[0] - sw) / 2, SIZE[1] - 160), signature, font=sf, fill=theme["accent"])
    return img


def style_list(text: str, theme: dict, signature: str) -> Image.Image:
    """清单：每行前面加个小圆点。"""
    img = Image.new("RGB", SIZE, theme["bg"])
    draw = ImageDraw.Draw(img)

    items = [x.strip() for x in (text or "").split("\n") if x.strip()]
    font, _ = _fit_font("\n".join(items), max(4, len(items) + 2), SIZE[0] - 260)
    lh = int(font.size * 1.9)
    top = max(240, (SIZE[1] - len(items) * lh) // 2)

    y = top
    for item in items:
        draw.ellipse([(150, y + font.size * 0.42), (150 + 16, y + font.size * 0.42 + 16)],
                     fill=theme["accent"])
        draw.text((200, y), item, font=font, fill=theme["fg"])
        y += lh

    if signature:
        sf = _font(FONT_NORMAL, 34)
        draw.text((200, y + 40), signature, font=sf, fill=theme["accent"])
    return img


STYLES = {
    "classic": style_classic,
    "quote": style_quote,
    "poem": style_poem,
    "note": style_note,
    "title_body": style_title_body,
    "list": style_list,
}


def render_card(
    text: str,
    out_path: str,
    style: str = "",
    theme: str = "",
    title: str = "",
    signature: str = "—— 糯糯",
) -> str:
    """按指定或随机样式渲染一张卡片。"""
    style_name = style if style in STYLES else random.choice(list(STYLES))
    theme_name = theme if theme in THEMES else random.choice(list(THEMES))
    palette = THEMES[theme_name]

    if style_name == "title_body":
        image = style_title_body(title or " ", text, palette, signature)
    else:
        image = STYLES[style_name](text, palette, signature)

    target = Path(out_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    image.save(target, "JPEG", quality=90)
    return str(target)