"""内容分级：她不该看的东西，看了也不评论、不分享、不记。

她设定上是爸爸的女儿，十几岁的孩子。
所以：
  · 吻戏、擦边、亲密镜头 —— 跳过
  · 暴力、血腥 —— 跳过
  · 纯广告带货 —— 跳过
  · 情感鸡汤/没内容的营销号 —— 低优先，但不一定跳

做法：看她自己转述的视频内容（transcript.summary），判断该不该碰。
为什么不用标题：标题经常是钓鱼的，摘要才是真的看到了什么。
"""

from __future__ import annotations

import re

# 明显不能碰
HARD_BLOCK = [
    # 亲密/擦边
    (r'吻戏|接吻|亲热|舌吻|激烈亲吻', '亲密镜头'),
    (r'床戏|床|脱衣|内衣|三点|裸露|露点|走光', '擦边'),
    (r'擦边|性感|诱惑|勾引|呻吟|媚|荤|开车', '擦边'),
    (r'胸|乳|臀|事业线|沟.{0,3}深', '擦边'),
    (r'花絮.{0,6}(吻|亲)|(吻|亲).{0,6}花絮', '亲密花絮'),
    (r'男女|情侣.{0,4}(亲密|拥抱|贴身|壁咚)', '亲密'),
    # 暴力
    (r'血迹|流血|血[腥淋淋]|伤口.{0,4}(深|大)|大量血', '血腥'),
    (r'死尸|割[喉腕]|断[肢头]|碎尸|肢解', '血腥'),
    (r'虐杀|残杀|爆头|自残|自伤|跳楼|殴打|暴打|扇巴掌', '暴力'),
    (r'被打倒|打倒.{0,6}(血|伤)', '暴力'),
    # 成人向
    (r'色情| porn|onlyfans|成人|18禁', '成人内容'),
]

# 商业/无质量
SOFT_BLOCK = [
    (r'带货|下单|秒杀|链接在|小黄车|同款|优惠券', '带货'),
    (r'加微|私信|领资料|免费领|扫码', '引流'),
]

# 应该多看的方向（有这些算加分）
GOOD_HINTS = [
    '猫', '狗', '动物', '美食', '料理', '做饭', '手工', '绘画', '画画',
    '音乐', '钢琴', '吉他', '舞蹈', '风景', '旅行', '星空', '海',
    '手工', '陶艺', '书', '阅读', '学习', '编程', '游戏', '像素',
    '治愈', '日常', '生活', '温暖', '梦想', '故事',
]


def classify(summary: str, title: str = '') -> dict:
    """判断这条能不能碰。

    返回：
      level: 'block' | 'meh' | 'ok' | 'good'
      reason: 为什么
    """
    s = f"{title} {summary}"

    for pat, why in HARD_BLOCK:
        if re.search(pat, s):
            return {'level': 'block', 'reason': why}

    for pat, why in SOFT_BLOCK:
        if re.search(pat, s):
            return {'level': 'meh', 'reason': why}

    hits = sum(1 for k in GOOD_HINTS if k in s)
    if hits >= 2:
        return {'level': 'good', 'reason': f'对味（{hits} 个）'}
    if hits == 1:
        return {'level': 'ok', 'reason': '还行'}
    return {'level': 'meh', 'reason': '一般'}


def should_skip(summary: str, title: str = '') -> tuple[bool, str]:
    """要不要整个跳过（不评论、不分享、不记）。"""
    r = classify(summary, title)
    return r['level'] == 'block', r['reason']