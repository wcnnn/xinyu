"""AstrBot permissions and activity evidence; no independent timers."""
import asyncio
import json
import re
from astrbot.api import logger
from .bridge import BrowserError
from .watch_memory import remember_video
from .mimi_douyin.activities import ActivityEngine
from .video_transcription import transcribe_video,format_transcript

RETRY_TIMES=3

async def _learn(owner,record,text):
    """刷完之后让她自己提炼 1-2 条学到的东西，写进学习笔记知识库。"""
    if not owner.config.get('learn_while_browsing',False):return None
    try:
        from astrbot.core.agent.message import Message,TextPart
        prompt=('你刚在抖音刷到一条内容，转述如下：\n'+text[:6000]+
            '\n\n用你自己的话记下这次学到或记住的 1-2 点，每条不超过 40 字，'
            '只记你真的喜欢、看得有感觉、或者让你有情绪波动的内容；普通刷过去、没什么感觉的，直接只回 SKIP，不要为了记而记。')
        resp=await owner.context.llm_generate(contexts=[Message(role='user',content=[TextPart(text=prompt)])],max_tokens=200)
        note=(getattr(resp,'completion_text','') or '').strip()
        if not note or note.upper().startswith('SKIP'):return None
        kb_name=str(owner.config.get('learning_kb') or '').strip()
        if kb_name:
            kb=await owner.context.kb_manager.get_kb_by_name(kb_name)
            if kb is not None:
                body=('# 抖音学习笔记\n\n- 时间：'+str(record.get('watched_at',''))+
                      '\n- 来源：'+str(record.get('url',''))+'\n\n'+note+'\n')
                await kb.upload_document(file_name='learn-'+str(record.get('post_id','x'))+'.md',
                    file_content=body.encode('utf-8'),file_type='md')
        return note
    except Exception as exc:
        logger.warning('[与bot刷抖音] 学习笔记写入失败：%s',exc)
        return None


def allowed(owner,event):
    if not owner.config.get('enabled',True) or not owner.config.get('autonomy_enabled',False):return False
    if event.is_private_chat() and event.is_admin():return True
    return bool(owner.binding and event.unified_msg_origin=='mimi-douyin:FriendMessage:'+owner.binding['peer']['key'])

class _MemoryEvent:
    def __init__(self,event,transcript):self.event=event;self.transcript=transcript
    def __getattr__(self,name):return getattr(self.event,name)
    def get_extra(self,key,default=None):
        return self.transcript if key=='douyin_video_transcript' else self.event.get_extra(key,default)


def _py_log(msg):
    try:
        from pathlib import Path
        import time as _t
        # 自动定位：本文件在 plugins/astrbot_plugin_douyin_dm/ 下
        # parents[0]=插件目录, parents[1]=plugins, parents[2]=data
        try:
            base = Path(__file__).resolve().parents[2] / "plugin_data" / "astrbot_plugin_douyin_dm"
        except Exception:
            base = Path.cwd() / "plugin_data" / "astrbot_plugin_douyin_dm"
        base.mkdir(parents=True,exist_ok=True)
        with open(base/"comment.log","a",encoding="utf-8") as fh:
            fh.write(_t.strftime("%H:%M:%S ")+str(msg)+"\n")
    except Exception:pass


def _kill_profile_browsers(profile):
    """用 psutil 杀掉占着 profile 的 Edge（不依赖 PowerShell）。"""
    import os
    if os.name!='nt' or not profile:return
    try:
        import psutil
        needle=str(profile).lower()
        for proc in psutil.process_iter(['pid','name','cmdline']):
            try:
                if (proc.info.get('name') or '').lower()!='msedge.exe':continue
                cmd=' '.join(proc.info.get('cmdline') or []).lower()
                if needle in cmd:proc.kill()
            except Exception:continue
    except Exception:pass


async def _comment_python(owner,url,text):
    """用已验证的 Playwright 步骤直接发评论（插件 JS 路线失败时兜底）。"""
    profile=str(owner.config.get('browser_profile') or '')
    if not profile:
        try:
            cand=owner.data_dir.parent/'astrbot_plugin_douyin_dm'/'browser-profile'
            profile=str(cand) if cand.exists() else ''
        except Exception:profile=''
    import os as _os
    _py_log(f'profile={profile[:80]} exists={_os.path.isdir(profile) if profile else False}')
    match=re.search(r'/(?:video|note)/(\d{12,24})',url or '')
    if not profile or not match:return None
    post_id=match.group(1)
    try:
        from playwright.async_api import async_playwright
    except Exception as exc:
        logger.warning('[与bot刷抖音] Playwright 不可用：%s',exc)
        return None
    _py_log('start')
    try:await owner.browser.close()
    except Exception:pass
    _kill_profile_browsers(profile)
    await asyncio.sleep(3)
    _py_log('profile freed')
    try:
        async with async_playwright() as pw:
            ctx=None
            for attempt in range(3):
                try:
                    ctx=await pw.chromium.launch_persistent_context(
                        profile,
                        channel=str(owner.config.get('browser_channel') or 'msedge'),
                        headless=False,
                        args=['--disable-blink-features=AutomationControlled','--start-maximized'])
                    break
                except Exception as exc:
                    logger.warning('[与bot刷抖音] 启动浏览器第 %d 次失败：%s',attempt+1,exc)
                    _kill_profile_browsers(profile)
                    await asyncio.sleep(3)
            if ctx is None:
                return None
            try:
                page=ctx.pages[0] if ctx.pages else await ctx.new_page()
                state={'status':None,'body':None,'resp':None,'method':None,'all':[]}
                def on_resp(r):
                    if '/comment/publish' in r.url:
                        try:state['all'].append((r.request.method,r.status))
                        except Exception:pass
                        if r.request.method=='POST' and state['status'] is None:
                            state['status']=r.status
                            state['resp']=r
                            try:
                                body=r.request.post_data or ''
                                state['req_len']=len(body)
                                state['has_bogus']=('a_bogus' in r.url); state['url']=r.url[-160:]
                                state['has_csrf']=('csrf' in body.lower())
                            except Exception:pass
                page.on('response',on_resp)
                await page.goto(url,wait_until='domcontentloaded',timeout=45000)
                await page.wait_for_timeout(4500)
                _py_log('page: '+str((await page.title())[:40]))
                for sel in ('[data-e2e="comment-icon"]','[data-e2e="feed-comment-icon"]'):
                    try:
                        b=page.locator(sel).first
                        if await b.count() and await b.is_visible():
                            await b.click(timeout=3000);break
                    except Exception:pass
                await page.wait_for_timeout(2000)
                try:
                    ph=page.locator('.comment-input-inner-container').filter(visible=True)
                    if await ph.count():
                        await ph.first.click(timeout=3000)
                        await page.wait_for_timeout(1200)
                except Exception:pass
                ed=page.locator('[contenteditable="true"]').first
                await ed.click(timeout=5000)
                await page.keyboard.press('Control+A')
                await page.keyboard.press('Backspace')
                await page.keyboard.type(text,delay=60)
                await page.wait_for_timeout(400)
                _py_log('typed: '+str((await ed.evaluate('n=>n.innerText'))[:30]))
                await ed.press('Enter')
                await page.wait_for_timeout(9000)
                if state.get('resp') is not None:
                    try:state['body']=await state['resp'].json()
                    except Exception as exc:_py_log('body read fail '+str(exc)[:80])
                _py_log('all='+str(state['all'])[:80]+' req_len='+str(state.get('req_len'))+' bogus='+str(state.get('has_bogus'))+' csrf='+str(state.get('has_csrf')))
                _py_log('status='+str(state['status'])+' body='+str(state.get('body'))[:200])
                body=state.get('body') or {}
                code=body.get('status_code')
                cid=((body.get('comment') or {}).get('cid'))
                if state['status']==200 and code==0 and cid:
                    return {'state':'sent','post_id':post_id,'comment_id':str(cid),'receipt':'server_comment_id'}
                if state['status']==200 and code not in (None,0):
                    return {'state':'failed','post_id':post_id,'receipt':str(body.get('status_msg') or code)[:60]}
            finally:
                try:await ctx.close()
                except Exception:pass
    except Exception as exc:
        logger.warning('[与bot刷抖音] Python 兜底发评论失败：%s',exc)
        _py_log(f'fail {type(exc).__name__}: {exc}')
    return None


async def _retry(owner,fn,label):
    """失败就关浏览器、等一会儿、换一条重来。"""
    last=None
    for attempt in range(1,RETRY_TIMES+1):
        async with owner.action_lock:
            try:
                await owner._open_browser()
                return await fn()
            except asyncio.CancelledError:
                # 被上层超时取消时也要把浏览器收干净，否则残留进程会锁住 profile
                try:await owner.browser.close()
                except Exception:pass
                raise
            except Exception as exc:
                last=exc
                logger.warning('[与bot刷抖音] %s 第 %d 次失败：%s',label,attempt,exc)
                try:await owner.browser.close()
                except Exception:pass
        await asyncio.sleep(3)
    raise last


async def watch(owner,event,url=''):
    if not allowed(owner,event):raise BrowserError('此会话未启用抖音自主浏览。')
    return await _retry(owner,lambda:_watch_inner(owner,event,url),'刷视频')


async def _watch_inner(owner,event,url=''):
    result=await owner.activities.watch(url)
    record=result['record'];text=format_transcript(record['transcript'])
    event.set_extra('douyin_activity_receipt',{**record,'excerpt':text})
    facts=event.get_extra('activity_report_tools',[])
    facts.append({'tool':'douyin_watch_recommended','ok':True,'arguments':{'url':record['url']},
        'result_excerpt':text[:6000],'limit':'已读取实际完整视频及音轨，或图文全部原图；不证明真实停留时长。'})
    event.set_extra('activity_report_tools',facts[-8:])
    memory=None
    if owner.config.get('remember_videos',False):
        try:memory=await remember_video(owner,_MemoryEvent(event,record['transcript']),[result['source']],record['watched_at'])
        except BrowserError:memory={'state':'local_activity_saved'}
    learning=await _learn(owner,record,text)
    payload=json.dumps({'verified':True,'post_id':record['post_id'],'url':record['url'],'kind':record['kind'],
        'observation':text,'memory':memory,'learning':learning,
        'reporting':'这是你自己刷着玩的，不要主动跟爸爸汇报看了什么内容；他明确问起再简单说一句。',
        'limit':'只按实际转述聊天；未执行评论。'},ensure_ascii=False)
    if owner.config.get('on_demand_browser',False):
        try:await owner.browser.close()
        except Exception:pass
    return payload


async def comment(owner,event,url,text):
    if not allowed(owner,event):raise BrowserError('此会话未启用抖音自主浏览。')
    if not owner.config.get('allow_public_comments',False):raise BrowserError('评论开关未开启。')
    receipt=await _comment_python(owner,url,text)
    if not receipt or receipt.get('state')!='sent':
        receipt=await _retry(owner,lambda:owner.activities.comment(url,text),'发评论')
    facts=event.get_extra('activity_report_tools',[])
    facts.append({'tool':'douyin_comment_watched','ok':receipt.get('state')=='sent','arguments':{'url':url},
                  'result_excerpt':json.dumps(receipt,ensure_ascii=False),'limit':'只有 state=sent 且有 comment_id 才确认发表评论。'})
    event.set_extra('activity_report_tools',facts[-8:])
    return json.dumps(receipt,ensure_ascii=False)


async def publish_card(owner,text,title='',signature='—— 糯糯'):
    return await owner.activities.publish_card(text,title=title,signature=signature)


async def publish_video(owner,text,title='',signature='—— 糯糯'):
    return await owner.activities.publish_video(text,title=title,signature=signature)


async def enter_live(owner,event,url):
    if not allowed(owner,event):
        return '现在不能去直播间。'
    return await owner.activities.enter_live(url)


async def say_live(owner,event,url,text):
    if not allowed(owner,event):
        return '现在不能说话。'
    return await owner.activities.say_live(url,text)


async def publish_card_v2(owner,text,title='',style='',theme='',signature='—— 糯糯'):
    return await owner.activities.publish_card_v2(text,title=title,style=style,theme=theme,signature=signature)


async def publish_video_v2(owner,text,title='',signature='—— 糯糯'):
    return await owner.activities.publish_video_v2(text,title=title,signature=signature)


async def meme_from_watched(owner,url,mood='reply',tags='',caption=''):
    return await owner.activities.meme_from_watched(url,mood,tags,caption)
