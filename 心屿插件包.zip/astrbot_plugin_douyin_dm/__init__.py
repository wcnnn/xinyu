"""Douyin private conversation bridge."""
